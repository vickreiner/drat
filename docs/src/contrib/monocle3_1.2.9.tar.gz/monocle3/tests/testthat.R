library(testthat)
library(monocle3)

test_check("monocle3")
