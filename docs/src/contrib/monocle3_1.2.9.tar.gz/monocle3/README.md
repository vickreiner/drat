MONOCLE 3
=======================

Monocle 3 is an analysis toolkit for single-cell RNA-Seq experiments.  To use this package, you 
will need the R statistical computing environment (version 3.0 or later)
and several packages available through Bioconductor and CRAN.

Details on how to install and use Monocle 3 are available on our website:

http://cole-trapnell-lab.github.io/monocle3/
